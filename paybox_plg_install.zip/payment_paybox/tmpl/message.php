<?php
/*
 * --------------------------------------------------------------------------------
   PayBox.Money  - J2Store - Payment Plugin - Paybox
 * --------------------------------------------------------------------------------
 * @package		Joomla! 2.5x
 * @subpackage	J2 Store
 * @author    	Galym Sarsebek - Weblogicx India http://www.weblogicxindia.com
 * @copyright	Copyright (c) 2020 PayBox Money Kazakhstan Ltd. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 * @link		https://paybox.money
 * --------------------------------------------------------------------------------
*/

defined('_JEXEC') or die('Restricted access'); ?>

<?php echo $vars->message; ?>
